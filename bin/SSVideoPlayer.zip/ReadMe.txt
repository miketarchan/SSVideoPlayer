to install the screensaver, just copy all files(and folders) to:
� - x32 -> "c:\Windows\System32\"
� - x64 -> "c:\Windows\SysWOW64", if this does not work, you must copy to the "c:\Windows\System32\"

contacts: muhasjo@gmail.com